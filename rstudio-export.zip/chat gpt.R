https://chatgpt.com/share/86eeda8d-a83d-4b6b-bdb2-0ec7ea2f40ea
